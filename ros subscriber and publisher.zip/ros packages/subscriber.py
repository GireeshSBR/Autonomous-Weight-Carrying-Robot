#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

sbname = 'sensor_receiver'
topicName = 'video_topic'

def callBackFunction(message):
	bridgeObject=CvBridge()
	rospy.loginfo("received the image/frame")
	ob=bridgeObject.imgmsg_to_cv2(message)
	cv2.imshow("camera",ob)
	cv2.waitKey(1)

rospy.init_node(sbname,anonymous=True)
rospy.Subscriber(topicName,Image,callBackFunction)
rospy.spin()
cv2.destroyAllWindows()
